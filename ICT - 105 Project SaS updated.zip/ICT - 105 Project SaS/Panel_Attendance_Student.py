import imports as i

account = {}

def attendance_student():

    def get_student_data(student_id):

        student_data = i.db.db_getStudentData(student_id)

        if account_role == "admin":
            student_id_label.config(text=f"{student_data[0][0]}")
            student_name_label.config(text=f"{student_data[0][1]}")
        else:
            n_id_label.config(text=f"ID   : \t{student_data[0][0]}")
            name_label.config(text=f"Name : \t{student_data[0][1]}")

        class_data = i.db.db_getClassList()

        # Insert data into the table with checkboxes
        for row in class_data:
            item_id = str(row[0])  # Using the ID as the row identifier
            checkbox_states[item_id] = False  # Initialize each checkbox as unchecked
            # Insert the row with an unchecked checkbox symbol
            checkbox_symbol = UNCHECKED
            table.insert("", "end", iid=item_id, values=(checkbox_symbol, row[1], row[2]))

    def update_attendance(class_data):
        if account_role == "admin":
            pass
        else:
            pass

    #-----------------------------------------------------
    #Setup window size and position
    panel_student_attendance = i.tk.Tk()
    panel_student_attendance.title("STUDENT ATTENDANCE (ADMIN)")
    panel_student_attendance = i.Functions.c_Panel_Setup.Panel_Setup(panel_student_attendance,600,450)
    #-----------------------------------------------------
    #Widgets

    account_role = i.Functions.user.role

    
    search_frame = i.tk.LabelFrame(panel_student_attendance, text="Search Student", font=("Helvetica", 10, "bold"))
    id_label = i.tk.Label(search_frame, text="ID:")
    id_entry = i.tk.Entry(search_frame, width=30)
    submit_button =i.tk.Button(search_frame, text="Search", command=lambda: get_student_data(id_entry.get()))

    student_frame = i.tk.LabelFrame(panel_student_attendance, font=("Helvetica", 10, "bold"),text="Student Information")
    space_label = i.tk.Label(student_frame, text="")
    n_id_label = i.tk.Label(student_frame, text="ID:")
    student_id_label = i.tk.Label(student_frame, text="",width=25)
    name_label = i.tk.Label(student_frame, text="Name:")
    student_name_label = i.tk.Label(student_frame, text="",width=25)

    listofClass = i.tk.LabelFrame(panel_student_attendance, font=("Helvetica", 10, "bold"),text="Student Class List")
    btn_attendance = i.tk.Button(listofClass,text="Update Attendance", command=lambda: update_attendance(),font=("Helvetica", 6))

    if account_role == "admin":
        search_frame.grid(padx=10,pady=10, row=0,column=0,sticky="nsew")
        # Add widgets inside the LabelFrame
        id_label.grid(row=0, column=0, sticky="w", padx=5, pady=5)
        id_entry.grid(row=0, column=1, padx=5, pady=5)
        submit_button.grid(row=0, column=2, columnspan=2, pady=5,padx=10)
        #==========================================================================
        student_frame.grid(padx=10,pady=10, row=0,column=1,sticky="nsew")
        space_label.grid(row=0, column=4, sticky="e", padx=5, pady=5)
        #--------------------------------------------------------------------------
        n_id_label.grid(row=0, column=0, sticky="e", padx=5, pady=5)
        student_id_label.grid(row=0, column=1, sticky="w", padx=5, pady=5)
        #--------------------------------------------------------------------------
        name_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)
        student_name_label.grid(row=1, column=1, sticky="w", padx=5, pady=5)
        #--------------------------------------------------------------------------
        listofClass.grid(padx=10,pady=10, row=1,column=0,columnspan=2,sticky="nsew")
        #--------------------------------------------------------------------------
    else:
        student_frame.pack(padx=10,pady=10,fill="both")
        #space_label.grid(column=1,row=0, padx=5, pady=5)
        #--------------------------------------------------------------------------
        n_id_label.grid(column=0,row=0,padx=1, pady=5,sticky="e")
        #student_id_label.grid(column=1,row=0, padx=1, pady=5)
        #--------------------------------------------------------------------------
        name_label.grid(column=0,row=1, padx=5, pady=5,sticky="e")
        #student_name_label.grid(column=1,row=1, padx=5, pady=5)
        #--------------------------------------------------------------------------
        listofClass = i.tk.LabelFrame(panel_student_attendance, font=("Helvetica", 10, "bold"),
                                      text=f"Student Class List for today ({i.datetime.now().date()})")
        listofClass.pack(padx=10,pady=10, fill="both")
        #--------------------------------------------------------------------------
        btn_attendance.config(text="Take Attendance")




    # Define columns for the table
    columns = ("Status", "ID", "Description")

    # Checkbox symbols
    CHECKED = "☑"
    UNCHECKED = "☐"

    # Dictionary to hold checkbox states
    checkbox_states = {}

    # Function to toggle checkbox state
    def toggle_checkbox(item_id):
        # Toggle the checkbox state for the item
        checkbox_states[item_id] = not checkbox_states[item_id]
        # Update the displayed checkbox symbol
        checkbox_symbol = CHECKED if checkbox_states[item_id] else UNCHECKED
        table.item(item_id, values=(checkbox_symbol,) + table.item(item_id, "values")[1:])

    # Create the Treeview widget with checkboxes

    table = i.ttk.Treeview(listofClass, columns=columns, show="headings", height=8)
    table.grid(row=1,column=0,pady=20,padx=30)

    # Define column headings
    table.heading("#1", text="Status")
    table.heading("#2", text="ID")
    table.heading("#3", text="Description")

    # Define column widths
    table.column("#1", anchor="center", width=50)  # Checkbox column
    table.column("#2", anchor="center", width=150)
    table.column("#3", anchor="center", width=300)

    # Bind a click event to toggle the checkbox state
    def on_click(event):
        # Get the clicked row item
        item_id = table.identify_row(event.y)
        # Check if it is in the checkbox column
        if table.identify_column(event.x) == "#1" and item_id:
            toggle_checkbox(item_id)

    # Bind the click event to the table
    table.bind("<Button-1>", on_click)

    btn_attendance.grid(row=2,column=0,padx=5,pady=5)

    date_label = i.tk.Label(panel_student_attendance, font=("Helvetica", 12),text=f"Date:  {i.datetime.now().date()}")
    
    if account_role == "student":
        get_student_data(account['username'])
    else:
        date_label.grid(row=2,column=0,padx=5, pady=5,sticky="w")

    panel_student_attendance.mainloop()
    

#attendance_student()




