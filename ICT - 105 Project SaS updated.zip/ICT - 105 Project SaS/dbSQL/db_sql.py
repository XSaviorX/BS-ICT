# import imports as i
import mysql.connector
from mysql.connector import Error

from imports import messagebox
from tkinter import messagebox, ttk


def db_connect():
    try:
        connection = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = 'ochirrej120796',
            database = 'sas'
        )

        if connection.is_connected():
            return connection
        
    except Error as e:
        return messagebox.showerror("ERROR",e)
    
def db_getAccount(parameters):
    try:
        conn = db_connect()
        cursor = conn.cursor()
        query = f"SELECT * FROM accounts WHERE a_username = '{parameters.id}' AND a_password = '{parameters.passw}'"
        cursor.execute(query)
        result = cursor.fetchall()
        
        for items in result:
            usern = items[1]
            passw = items[2]
            role = items[3]

        acount_info = {'username':usern,
                       'password':passw,
                       'role':role}

        return acount_info
        
    except Error as e:
        return messagebox.showerror("LOGIN ERROR",e)
    
#Getting student account
def db_getStudentData(student_id):
    try:
        #i.messagebox.showinfo("getStudentData", student_id)
        conn = db_connect()
        cursor = conn.cursor()
        query = f"SELECT * FROM student WHERE student_id = '{student_id}'"
        cursor.execute(query)
        result = cursor.fetchall()
        return result
        
    except Error as e:
        return messagebox.showerror("GET STUDENT DATA",e)
    
#get Class List
def db_getClassList():
    try:
        #i.messagebox.showinfo("getStudentData", student_id)
        conn = db_connect()
        cursor = conn.cursor()
        query = f"SELECT class_id,course_code,course_name,class_date FROM class_list"
        cursor.execute(query)
        result = cursor.fetchall()
        return result

    except Error as e:
        return messagebox.showerror("GET CLASS LIST",e)

# get all courses
def db_getCourses():
    try:
        #i.messagebox.showinfo("getStudentData", student_id)
        conn = db_connect()
        cursor = conn.cursor()
        query = f"SELECT * FROM courses"
        cursor.execute(query)
        result = cursor.fetchall()
        return result

    except Error as e:
        return messagebox.showerror("GET COURSE LIST",e)
    

# create class attendance
def db_create_class_attendance(class_req):
    try:
        # i.messagebox.showinfo("das", class_req)
        conn = db_connect()
        cursor = conn.cursor()
        query = f"INSERT INTO classes (course_code, class_date, class_time, room) VALUES (%s,%s,%s,%s)"
        values = (class_req['code'],class_req['date'],class_req['time'],class_req['room'])
        cursor.execute(query,values)
        conn.commit()

        messagebox.showinfo("CLASS ATTENDANCE INFO", "Creating of class attendance is successful \n\n " +
                               " You can now check the added record in the table")

    except Error as e:
        return messagebox.showerror("CREATE CLASS ATTENDANCE",e)
    
#get User List
def db_getUserList():
    try:
        #i.messagebox.showinfo("getStudentData", student_id)
        conn = db_connect()
        cursor = conn.cursor()
        query = f"SELECT * FROM user_list"
        cursor.execute(query)
        result = cursor.fetchall()
        return result

    except Error as e:
        return messagebox.showerror("GET USER LIST",e)

    
            
















# import sqlite3

# def add_student(student_id, name, course):
#     connection = sqlite3.connect("attendance.db")
#     cursor = connection.cursor()
#     cursor.execute("INSERT INTO students (id, name, course) VALUES (?, ?, ?)", (student_id, name, course))
#     connection.commit()
#     connection.close()
#     print(f"Added student: {name}")

# def view_students():
#     connection = sqlite3.connect("attendance.db")
#     cursor = connection.cursor()
#     cursor.execute("SELECT * FROM students")
#     students = cursor.fetchall()
#     connection.close()
#     print("Student List:")
#     for student in students:
#         print(student)

# # Example console-based role-based login
# def role_based_login():
#     if login("instructor_password.hash"):
#         print("Login successful. Role: Instructor.")
#     else:
#         print("Invalid login.")
