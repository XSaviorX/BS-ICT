import imports as i
import Panel_Login
#----------------------------------------------------
#Panel Functions

def run_program():

    #i.db.db_connect()
    #run login page
    Panel_Login.Login()

#Starting point
run_program()   