import imports as i

def report_class():
    #-----------------------------------------------------
    #Setup window size and position
    panel_attendance_class = i.tk.Tk()
    panel_attendance_class.title("CLASS REPORT")
    panel_attendance_class = i.Functions.c_Panel_Setup.Panel_Setup(panel_attendance_class,900,450)
    #-----------------------------------------------------

    


def report_student():
    #-----------------------------------------------------
    #Setup window size and position
    panel_attendance_class = i.tk.Tk()
    panel_attendance_class.title("CLASS ATTENDANCE (ADMIN)")
    panel_attendance_class = i.Functions.c_Panel_Setup.Panel_Setup(panel_attendance_class,900,450)
    #-----------------------------------------------------