import Panel_Login
#----------------------------------------------------
#Panel Functions

def run_program():

    #run login page
    Panel_Login.Login()

#Starting point
run_program()   